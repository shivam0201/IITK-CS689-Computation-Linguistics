The file must be opened in Juypter notebook for better code representation and understanding

Downloading the 'hi_100.txt' corpus from https://bangla.iitk.ac.in/assignment_cs689/cs689_100mbs/ using wget command.

The cells need to be run in the order they are arranged for satisfactory results, some cells take data from above cells, hence order must be preserved.

The program has been checked for a sample file names hi_10.txt that contains first 10000 lines of actual corpus.The reason to not use actual corpus is my personal computer crashed everytime I tried using the 100MB corpus file ie hi_100.txt.

This program would work correctly for hi_100.txt given sufficient computing power and time.

This jupyter notebook contains only question 1, 2 and 4. Question 3 has been done on https://bangla.iitk.ac.in/cs689/main.
Completing question 1 is necessary for question 4. 

The program has arbitary unigram and bigram character and syllable values based on a smaller corpus.