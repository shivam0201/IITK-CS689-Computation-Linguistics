def read_file(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        data = []
        for line in lines:
            elements = line.strip().split(',')
            data.append(elements)
    return data

# Example usage:
p1 = 'ground_truth_tags_only.txt'  # Ground truth file
ground = read_file(p1)
p2 = 'indicBERT-tags.txt'  # Please update this file path to compare 
prediction = read_file(p2)
# print(ground)
# print("--------------------------------------------------------------------------------------------")
# print(prediction)
# print("-----------------------------------------------------------------------------------------------------------------------------")

true_labels = ['O', 'B-PER', 'I-PER', 'B-ORG', 'I-ORG', 'B-LOC', 'I-LOC','B-MISC','I-MISC']

# Convert each element to string
true_label = [str(label) for true_label in ground for label in true_label]
predicted_label = [str(label) for predicted_label in prediction for label in predicted_label]

# print(true_label)
# print("-----------------------------------")
# print(predicted_label)



# Determine the minimum length between the two datasets
min_length = min(len(true_label), len(predicted_label))

# Truncate both datasets to the minimum length
true_label = true_label[:min_length]
predicted_label = predicted_label[:min_length]



# Calculate classification report
report = classification_report(true_label, predicted_label, labels=true_labels)

# Calculate overall accuracy
overall_accuracy = accuracy_score(true_label, predicted_label)

# Print the classification report
print(report)

# Print overall accuracy
print("Overall Accuracy:", overall_accuracy)