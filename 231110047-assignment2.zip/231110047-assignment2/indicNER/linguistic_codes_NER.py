#!/usr/bin/env python
# coding: utf-8

# Let's download the Naampadam (Indic NER) dataset
from datasets import ClassLabel, load_dataset, load_metric, DownloadMode

lang='hi'

raw_datasets = load_dataset('ai4bharat/naamapadam', lang,cache_dir='.cache')


# In[2]:


raw_datasets
# In[4]:


column_names = raw_datasets["train"].column_names
print(column_names)

features = raw_datasets["train"].features

print(features)


# In[5]:


text_column_name = "tokens"
label_column_name = "ner_tags"


# In[6]:


# If the labels are of type ClassLabel, they are already integers and we have the map stored somewhere.

label_list = features[label_column_name].feature.names

label_to_id = {label_list[i]: features[label_column_name].feature.str2int( label_list[i] ) for i in range(len(label_list))}

print(label_to_id)

num_labels = len(label_list)
# In[7]:


from transformers import AutoModelForTokenClassification, AutoConfig, AutoTokenizer, TrainingArguments, Trainer, DataCollatorForTokenClassification, EarlyStoppingCallback, IntervalStrategy
import numpy as np

config = AutoConfig.from_pretrained('ai4bharat/IndicNER', num_labels=num_labels, finetuning_task='ner_tags')
tokenizer = AutoTokenizer.from_pretrained("ai4bharat/IndicNER")
model = AutoModelForTokenClassification.from_pretrained('ai4bharat/IndicNER', num_labels=num_labels )


# In[8]:


# Run the next cell if you want to use a GPU. Make sure that the Colab runtime is set accordingly

model=model.to("cuda")


# In[9]:


# Tokenize all texts and align the labels with them.
padding = "max_length"
def tokenize_and_align_labels(examples):
    tokenized_inputs = tokenizer(
        examples[text_column_name],
        padding=padding,
        truncation=True,
        max_length=128,
        # We use this argument because the texts in our dataset are lists of words (with a label for each word).
        is_split_into_words=True,
    )
    labels = []
    for i, label in enumerate(examples[label_column_name]):
        # print('=====')
        # print('{} {}'.format(i,label)) #ak
        word_ids = tokenized_inputs.word_ids(batch_index=i)
        
        previous_word_idx = None
        label_ids = []
        for word_idx in word_ids:
            # Special tokens have a word id that is None. We set the label to -100 so they are automatically
            # ignored in the loss function.
            if word_idx is None:
                label_ids.append(-100)
            # We set the label for the first token of each word.
            elif word_idx != previous_word_idx:
                label_ids.append(label[word_idx])
            # For the other tokens in a word, we set the label to either the current label or -100, depending on
            # the label_all_tokens flag.
            else:
                label_ids.append(-100)
            previous_word_idx = word_idx

        labels.append(label_ids)
    tokenized_inputs["labels"] = labels
    return tokenized_inputs


# In[104]:


train_dataset = raw_datasets["train"]
train_dataset = train_dataset.select(range(20000))  # Select only the first 30,000 lines
train_dataset = train_dataset.map(
    tokenize_and_align_labels,
    batched=True,
    num_proc=16,
    load_from_cache_file=True,
    desc="Running tokenizer on train dataset",
)


# In[105]:


eval_dataset = raw_datasets["validation"]
eval_dataset = eval_dataset.map(
    tokenize_and_align_labels,
    batched=True,
    num_proc=16,
    load_from_cache_file=True,
    desc="Running tokenizer on Validation dataset",
)

# In[107]:


data_collator = DataCollatorForTokenClassification(tokenizer)


# In[108]:


# Metrics
metric = load_metric("seqeval")

def compute_metrics(p):
    predictions, labels = p
    predictions = np.argmax(predictions, axis=2)

    # Remove ignored index (special tokens)
    true_predictions = [
        [label_list[p] for (p, l) in zip(prediction, label) if l != -100]
        for prediction, label in zip(predictions, labels)
    ]
    true_labels = [
        [label_list[l] for (p, l) in zip(prediction, label) if l != -100]
        for prediction, label in zip(predictions, labels)
    ]

    results = metric.compute(predictions=true_predictions, references=true_labels)
    # Unpack nested dictionaries
    final_results = {}
    for key, value in results.items():
        if isinstance(value, dict):
            for n, v in value.items():
                final_results[f"{key}_{n}"] = v
        else:
            final_results[key] = value
    return final_results


# In[113]:


# args=TrainingArguments(output_dir='output_dir',max_steps=5)
args=TrainingArguments(
    output_dir='output_dir',
    per_device_train_batch_size=8,
    per_device_eval_batch_size=8,
    learning_rate=4e-5,
    num_train_epochs=3.0,
    evaluation_strategy='epoch',
    fp16=True,
    accelerator_config={'split_batches': True, 'dispatch_batches': None, 'even_batches': True, 'use_seedable_sampler': True},
)


# In[114]:


# Initialize our Trainer
# early_stopping_callback = EarlyStoppingCallback(early_stopping_patience=2)
# args.metric_for_best_model = "f1"
# args.load_best_model_at_end = True
# args.evaluation_strategy = IntervalStrategy.STEPS
# args.eval_steps = args.save_steps
# args.greater_is_better = True

trainer = Trainer(
    model=model,
    train_dataset=train_dataset,
    eval_dataset=eval_dataset,
    tokenizer=tokenizer,
    data_collator=data_collator,
    compute_metrics=compute_metrics,
    # callbacks=[early_stopping_callback],
    args=args,
)


# In[115]:


trainer.args


# In[116]:


train_result = trainer.train()
metrics = train_result.metrics


# In[ ]:


def save_metrics_to_file(metrics, file_path):
    with open(file_path, 'w') as f:
        for key, value in metrics.items():
            f.write(f"{key}: {value}\n")

if __name__ == "__main__":
    metrics = trainer.evaluate()
    trainer.log_metrics("eval", metrics)
    metrics_file = "eval_metrics_ner.txt"
    save_metrics_to_file(metrics, metrics_file)


# In[ ]:


test_dataset = raw_datasets["test"]
test_dataset = test_dataset.map(
    tokenize_and_align_labels,
    batched=True,
    num_proc=16,
    load_from_cache_file=True,
    desc="Running tokenizer on train dataset",
)


# In[99]:


tokenized_test_set = {}

for lang in raw_datasets:
  tokenized_test_set[lang] = raw_datasets['test'].map(
      tokenize_and_align_labels,
      batched=True,
      num_proc=8,
      load_from_cache_file=True,
      desc="Running tokenizer on test dataset of language {0}".format(lang),
  )


# In[100]:


final_metrics = {}

for lang in tokenized_test_set:
  predictions, labels, metrics = trainer.predict(tokenized_test_set[lang], metric_key_prefix=lang)

  lang_specific_results = {}
  for key in metrics:
    if 'overall_precision' in key:
      lang_specific_results['Precision'] = metrics[key]
    elif 'overall_recall' in key:
      lang_specific_results['Recall'] = metrics[key]
    elif 'overall_f1' in key:
      lang_specific_results['F1'] = metrics[key]
  final_metrics[lang] = lang_specific_results


# In[101]:


import pandas as pd

combined_results = pd.DataFrame.from_dict(
            final_metrics, orient="index"
        )

print(combined_results)
combined_results.to_csv("test_metrics_ner.csv")


# In[ ]:


model.save_pretrained('my_indicNER')


# In[ ]:


tokenizer.save_pretrained("tokenizer_indicNER")


# In[35]:


id2label = {
    str(i): label for i,label in enumerate(label_list)
}
label2id = {
    label: str(i) for i,label in enumerate(label_list)
}


# In[32]:


import json
import torch


# In[33]:


config = json.load(open("my_indicNER/config.json"))


# In[36]:


config["id2label"] = id2label
config["label2id"] = label2id


# In[38]:


json.dump(config, open("my_indicNER/config.json","w"))


# In[39]:


model_fine_tuned = AutoModelForTokenClassification.from_pretrained("my_indicNER")


# In[61]:

"""
def get_ner(sentence):
    tok_sentence = tokenizer(sentence, return_tensors='pt')

    with torch.no_grad():
        logits = model_fine_tuned(**tok_sentence).logits.argmax(-1)
        predicted_tokens_classes = [
            model_fine_tuned.config.id2label[t.item()] for t in logits[0]]

        predicted_labels = []

        previous_token_id = 0
        word_ids = tok_sentence.word_ids()
        for word_index in range(len(word_ids)):
            if word_ids[word_index] == None:
                previous_token_id = word_ids[word_index]
            elif word_ids[word_index] == previous_token_id:
                previous_token_id = word_ids[word_index]
            else:
                predicted_labels.append(predicted_tokens_classes[word_index])
                previous_token_id = word_ids[word_index]

        ner_output = []
        for index in range(len(sentence.split(' '))):
            if(index<len(predicted_labels)):
                ner_output.append((sentence.split(' ')[index], predicted_labels[index]))
            else:
                ner_output.append((sentence.split(' ')[index], 'O'))
        return ner_output


# In[89]:


sentences = []
with open('ground_truth_words_only.txt', 'r', encoding='utf-8') as file:
    for line in file:
        line = line.strip(" ")
        sentences.extend(line.split('\n'))

# Process each sentence and get NER results
ner_results = []
for sentence in sentences:
    if sentence.strip() == "":
        continue
    result = get_ner(sentence)
    ner_results.append(result)

print(ner_results)

# print(ner_results)


# In[90]:


with open('indicNER-prediction.txt', 'r', encoding='utf-8') as file:
    # Read the contents of the file
    sample_data = file.read()
    
# Parse the sample data string
parsed_data = eval(sample_data)

# Initialize an empty list to store the second values from each pair in all lists
second_values_list = []

# Iterate through each list of pairs in the parsed data
for sublist in ner_results:
    # Initialize an empty list to store the second values from pairs in the current sublist
    second_values_sublist = []
    
    # Iterate through each pair in the current sublist
    for pair in sublist:
        # Extract the second value from the current pair and append it to the sublist
        second_value = pair[1]
        second_values_sublist.append(second_value)
    
    # Append the sublist containing second values to the main list
    second_values_list.append(second_values_sublist)

# Print the resulting list of lists
print(second_values_list)


# In[91]:


# Write the resulting list of lists to a text file
with open('indicNER-tags.txt', 'w') as file:
    for sublist in second_values_list:
        file.write(','.join(sublist) + '\n')

print("Result has been saved in 'indicNER-tags.txt'")


# In[102]:


from sklearn.metrics import classification_report, accuracy_score

def read_file(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()
        data = []
        for line in lines:
            elements = line.strip().split(',')
            data.append(elements)
    return data

# Example usage:
p1 = 'ground_truth_tags_only.txt'  # Update with your file path
ground = read_file(p1)
p2 = 'indicNER-tags.txt'  # Update with your file path
prediction = read_file(p2)
# print(ground)
# print("--------------------------------------------------------------------------------------------")
# print(prediction)
# print("-----------------------------------------------------------------------------------------------------------------------------")

true_labels = ['O', 'B-PER', 'I-PER', 'B-ORG', 'I-ORG', 'B-LOC', 'I-LOC','B-MISC','I-MISC']

# Convert each element to string
true_label = [str(label) for true_label in ground for label in true_label]
predicted_label = [str(label) for predicted_label in prediction for label in predicted_label]

# print(true_label)
# print("-----------------------------------")
# print(predicted_label)



# Determine the minimum length between the two datasets
min_length = min(len(true_label), len(predicted_label))

# Truncate both datasets to the minimum length
true_label = true_label[:min_length]
predicted_label = predicted_label[:min_length]



# Calculate classification report
report = classification_report(true_label, predicted_label, labels=true_labels)

# Calculate overall accuracy
overall_accuracy = accuracy_score(true_label, predicted_label)

# Print the classification report
print(report)

# Print overall accuracy
print("Overall Accuracy:", overall_accuracy)


# In[ ]:
"""
