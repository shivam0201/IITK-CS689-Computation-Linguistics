from nltk.translate.bleu_score import sentence_bleu, corpus_bleu
from rouge_score import rouge_scorer
from collections import defaultdict

def read_sentences(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        sentences = file.readlines()
    return [sentence.strip() for sentence in sentences]

def calculate_sentence_bleu(reference_sentence, hypothesis_sentence):
    return sentence_bleu([reference_sentence.split()], hypothesis_sentence.split())

def calculate_corpus_bleu(reference_sentences, hypothesis_sentences):
    return corpus_bleu([[ref.split()] for ref in reference_sentences], [hyp.split() for hyp in hypothesis_sentences])

def calculate_rouge_scores(reference_sentences, hypothesis_sentences):
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    rouge_scores = scorer.score("\n".join(reference_sentences), "\n".join(hypothesis_sentences))
    return rouge_scores

def print_scores(reference_file, hypothesis_file):
    reference_sentences = read_sentences(reference_file)
    hypothesis_sentences = read_sentences(hypothesis_file)

    sentence_bleu_scores = []
    for ref, hyp in zip(reference_sentences, hypothesis_sentences):
        sentence_bleu_scores.append(calculate_sentence_bleu(ref, hyp))

    corpus_bleu_score = calculate_corpus_bleu(reference_sentences, hypothesis_sentences)
    rouge_scores = calculate_rouge_scores(reference_sentences, hypothesis_sentences)

    print("Sentence BLEU Scores:")
    for i, score in enumerate(sentence_bleu_scores):
        print(f"Sentence {i+1}: {score}")

    print("\nCorpus BLEU Score:", corpus_bleu_score)

    print("\nROUGE Scores:")
    for key, value in rouge_scores.items():
        print(f"{key}: {value}")

# Example usage:
reference_file = "test_1000.hi"
hypothesis_file = "NLLB/en_hi.hi"

print_scores(reference_file, hypothesis_file)