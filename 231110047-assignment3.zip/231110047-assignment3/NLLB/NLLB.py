#!/usr/bin/env python
# coding: utf-8

# In[1]:


from transformers import NllbTokenizer

tokenizer = NllbTokenizer.from_pretrained("facebook/nllb-200-distilled-600M")
tokenizer("How was your day?").input_ids


# In[3]:


"""import random

def read_files(file_names):
    sentences_pairs = []
    with open(file_names[0], 'r', encoding='utf-8') as file1, \
         open(file_names[1], 'r', encoding='utf-8') as file2, \
         open(file_names[2], 'r', encoding='utf-8') as file3:
        for line1, line2, line3 in zip(file1, file2, file3):
            sentences_pairs.append((line1, line2, line3))
    return sentences_pairs

def write_files(file_names, sentences_pairs):
    for i, file_name in enumerate(file_names):
        with open(file_name, 'w', encoding='utf-8') as file:
            for sentence_pair in sentences_pairs:
                file.write(sentence_pair[i])

def select_random_pairs(sentences_pairs, num_pairs):
    return random.sample(sentences_pairs, min(num_pairs, len(sentences_pairs)))

def main():
    num_pairs = 1000
    file_names = ["test.en", "test.hi", "test.te"]

    # Read pairs of sentences from all three files
    sentences_pairs = read_files(file_names)

    # Select random pairs
    selected_pairs = select_random_pairs(sentences_pairs, num_pairs)

    # Write selected pairs to new files
    write_files(["test_1000.en", "test_1000.hi", "test_1000.te"], selected_pairs)

if __name__ == "__main__":
    main()
"""


# In[4]:


from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

tokenizer = AutoTokenizer.from_pretrained("facebook/nllb-200-distilled-600M")
model = AutoModelForSeq2SeqLM.from_pretrained("facebook/nllb-200-distilled-600M", cache_dir=".cache")

article = "UN Chief says there is no military solution in Syria"
inputs = tokenizer(article, return_tensors="pt")

translated_tokens = model.generate(
    **inputs, forced_bos_token_id=tokenizer.lang_code_to_id["hin_Deva"], max_length=30
)
tokenizer.batch_decode(translated_tokens, skip_special_tokens=True)[0]


# In[ ]:


from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

def translate_sentences(input_file, output_file):
    tokenizer = AutoTokenizer.from_pretrained("facebook/nllb-200-distilled-600M")
    model = AutoModelForSeq2SeqLM.from_pretrained("facebook/nllb-200-distilled-600M", cache_dir=".cache")

    # Read input file
    with open(input_file, "r", encoding="utf-8") as file:
        sentences = file.readlines()

    counter=0
    # Translate each sentence and store in a list
    translated_sentences = []
    for sentence in sentences:
        inputs = tokenizer(sentence, return_tensors="pt")
        translated_tokens = model.generate(
            **inputs, forced_bos_token_id=tokenizer.lang_code_to_id["hin_Deva"], max_length=30
        )
        translated_sentence = tokenizer.batch_decode(translated_tokens, skip_special_tokens=True)[0]
        translated_sentences.append(translated_sentence)
        counter+=1
        if counter%100==0:
            print(f"Processed {counter} sentences.")

    # Write translated sentences to output file
    with open(output_file, "w", encoding="utf-8") as file:
        for translated_sentence in translated_sentences:
            file.write(translated_sentence + "\n")

# Example usage
translate_sentences("test_1000.en", "en_hi.hi")



# In[ ]:


from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

def translate_sentences(input_file, output_file):
    tokenizer = AutoTokenizer.from_pretrained("facebook/nllb-200-distilled-600M")
    model = AutoModelForSeq2SeqLM.from_pretrained("facebook/nllb-200-distilled-600M", cache_dir=".cache")

    # Read input file
    with open(input_file, "r", encoding="utf-8") as file:
        sentences = file.readlines()

    counter=0
    # Translate each sentence and store in a list
    translated_sentences = []
    for sentence in sentences:
        inputs = tokenizer(sentence, return_tensors="pt")
        translated_tokens = model.generate(
            **inputs, forced_bos_token_id=tokenizer.lang_code_to_id["eng_Latn"], max_length=30
        )
        translated_sentence = tokenizer.batch_decode(translated_tokens, skip_special_tokens=True)[0]
        translated_sentences.append(translated_sentence)
        counter+=1
        if counter%100==0:
            print(f"Processed {counter} sentences.")

    # Write translated sentences to output file
    with open(output_file, "w", encoding="utf-8") as file:
        for translated_sentence in translated_sentences:
            file.write(translated_sentence + "\n")

# Example usage
translate_sentences("test_1000.hi", "hi_en.en")



# In[ ]:


from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

def translate_sentences(input_file, output_file):
    tokenizer = AutoTokenizer.from_pretrained("facebook/nllb-200-distilled-600M")
    model = AutoModelForSeq2SeqLM.from_pretrained("facebook/nllb-200-distilled-600M", cache_dir=".cache")

    # Read input file
    with open(input_file, "r", encoding="utf-8") as file:
        sentences = file.readlines()

    counter=0
    # Translate each sentence and store in a list
    translated_sentences = []
    for sentence in sentences:
        inputs = tokenizer(sentence, return_tensors="pt")
        translated_tokens = model.generate(
            **inputs, forced_bos_token_id=tokenizer.lang_code_to_id["tel_Telu"], max_length=30
        )
        translated_sentence = tokenizer.batch_decode(translated_tokens, skip_special_tokens=True)[0]
        translated_sentences.append(translated_sentence)
        counter+=1
        if counter%100==0:
            print(f"Processed {counter} sentences.")

    # Write translated sentences to output file
    with open(output_file, "w", encoding="utf-8") as file:
        for translated_sentence in translated_sentences:
            file.write(translated_sentence + "\n")

# Example usage
translate_sentences("test_1000.hi", "hi_te.te")



# In[ ]:


from transformers import AutoModelForSeq2SeqLM, AutoTokenizer

def translate_sentences(input_file, output_file):
    tokenizer = AutoTokenizer.from_pretrained("facebook/nllb-200-distilled-600M")
    model = AutoModelForSeq2SeqLM.from_pretrained("facebook/nllb-200-distilled-600M", cache_dir=".cache")

    # Read input file
    with open(input_file, "r", encoding="utf-8") as file:
        sentences = file.readlines()

    counter=0
    # Translate each sentence and store in a list
    translated_sentences = []
    for sentence in sentences:
        inputs = tokenizer(sentence, return_tensors="pt")
        translated_tokens = model.generate(
            **inputs, forced_bos_token_id=tokenizer.lang_code_to_id["hin_Deva"], max_length=30
        )
        translated_sentence = tokenizer.batch_decode(translated_tokens, skip_special_tokens=True)[0]
        translated_sentences.append(translated_sentence)
        counter+=1
        if counter%100==0:
            print(f"Processed {counter} sentences.")

    # Write translated sentences to output file
    with open(output_file, "w", encoding="utf-8") as file:
        for translated_sentence in translated_sentences:
            file.write(translated_sentence + "\n")

# Example usage
translate_sentences("test_1000.te", "te_hi.hi")



# In[20]:


"""from nltk.translate.bleu_score import corpus_bleu
from nltk.translate.bleu_score import sentence_bleu
from rouge_score import rouge_scorer

def read_sentences(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        sentences = file.readlines()
    return [sentence.strip() for sentence in sentences]

def calculate_bleu_score(reference_file, hypothesis_file):
    reference_sentences = read_sentences(reference_file)
    hypothesis_sentences = read_sentences(hypothesis_file)
    bleu_score = corpus_bleu([[ref.split()] for ref in reference_sentences], [hyp.split() for hyp in hypothesis_sentences])
    return bleu_score

def calculate_rouge_score(reference_file, hypothesis_file):
    reference_sentences = read_sentences(reference_file)
    hypothesis_sentences = read_sentences(hypothesis_file)
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    rouge_scores = scorer.score("\n".join(reference_sentences), "\n".join(hypothesis_sentences))
    return rouge_scores

# Example of how to use the functions to calculate scores for each model and task
translation_tasks = ["task1", "task2", "task3"]
models = ["model1", "model2", "model3"]

for task in translation_tasks:
    print(f"Scores for translation task: {task}")
    for model in models:
        print(f"Model: {model}")
        reference_file = f"{task}_reference.hi"
        hypothesis_file = f"{task}_{model}_translation.hi"
        bleu_score = calculate_bleu_score(reference_file, hypothesis_file)
        rouge_scores = calculate_rouge_score(reference_file, hypothesis_file)
        print(f"BLEU Score: {bleu_score}")
        print(f"ROUGE-1 Score: {rouge_scores['rouge1'].fmeasure}")
        print(f"ROUGE-2 Score: {rouge_scores['rouge2'].fmeasure}")
        print(f"ROUGE-L Score: {rouge_scores['rougeL'].fmeasure}")
        print()
"""


# In[22]:


"""from nltk.translate.bleu_score import corpus_bleu
from rouge_score import rouge_scorer

def read_sentences(file_path):
    with open(file_path, "r", encoding="utf-8") as file:
        sentences = file.readlines()
    return [sentence.strip() for sentence in sentences]

def calculate_bleu_score(reference_file, hypothesis_file):
    reference_sentences = read_sentences(reference_file)
    hypothesis_sentences = read_sentences(hypothesis_file)
    bleu_score = corpus_bleu([[ref.split()] for ref in reference_sentences], [hyp.split() for hyp in hypothesis_sentences])
    return bleu_score

def calculate_rouge_score(reference_file, hypothesis_file):
    reference_sentences = read_sentences(reference_file)
    hypothesis_sentences = read_sentences(hypothesis_file)
    scorer = rouge_scorer.RougeScorer(['rouge1', 'rouge2', 'rougeL'], use_stemmer=True)
    rouge_scores = scorer.score("\n".join(reference_sentences), "\n".join(hypothesis_sentences))
    return rouge_scores

# Calculate scores for text.hi and pdt_test.hi
reference_file = "test.hi"
hypothesis_file = "pdt_test.hi"

bleu_score = calculate_bleu_score(reference_file, hypothesis_file)
rouge_scores = calculate_rouge_score(reference_file, hypothesis_file)

print("BLEU Score:", bleu_score)
print("ROUGE Scores:", rouge_scores)
"""

